package com.example.purchase.service;

import com.example.purchase.domain.OrderVO;
import com.example.user.domain.CartVO;

public interface OrderService {
	public void insert(OrderVO vo);
	public void insertpd(OrderVO vo);
	
	
	
}
