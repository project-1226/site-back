package com.example.user.service;

public interface ProductReviewService {
	
}
