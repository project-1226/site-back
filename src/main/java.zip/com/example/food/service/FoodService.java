package com.example.food.service;

import org.springframework.stereotype.Service;

@Service
public class FoodService {
	
	//식단추천하는 로직....js로짜고있긴한데 java로 바꿔야할듯
}
