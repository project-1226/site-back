package com.example.exercise;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AiexerciseVO {
	private String userid;
	private int aidataid;
	private String result;
	private Date regdate;
	private String ainame;
	private String link;
	
	
	
	
	
}
